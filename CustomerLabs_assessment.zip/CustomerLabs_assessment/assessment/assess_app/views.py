from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, generics
from .models import Account, Destination
from .assese import AccountSerializer, DestinationSerializer
import requests


# Account CRUD
class AccountViewSet(generics.ListCreateAPIView):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer


class AccountDetailViewSet(generics.RetrieveUpdateDestroyAPIView):
    queryset = Account.objects.all()
    serializer_class = AccountSerializer


# Destination CRUD
class DestinationViewSet(generics.ListCreateAPIView):
    queryset = Destination.objects.all()
    serializer_class = DestinationSerializer


class DestinationDetailViewSet(generics.RetrieveUpdateDestroyAPIView):
    queryset = Destination.objects.all()
    serializer_class = DestinationSerializer


# Get Destinations for Account
class AccountDestinationsView(APIView):
    def get(self, request, account_id):
        try:
            account = Account.objects.get(account_id=account_id)
            destinations = account.destinations.all()
            serializer = DestinationSerializer(destinations, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Account.DoesNotExist:
            return Response({"error": "Account not found"}, status=status.HTTP_404_NOT_FOUND)


# Handle Incoming Data
class IncomingDataView(APIView):
    def post(self, request):
        # Verify app secret token
        app_secret_token = request.headers.get("CL-X-TOKEN")
        if not app_secret_token:
            return Response({"error": "Un Authenticate"}, status=status.HTTP_401_UNAUTHORIZED)

        try:
            account = Account.objects.get(app_secret_token=app_secret_token)
        except Account.DoesNotExist:
            return Response({"error": "Un Authenticate"}, status=status.HTTP_401_UNAUTHORIZED)

        # Process data
        data = request.data
        if not isinstance(data, dict):
            return Response({"error": "Invalid Data"}, status=status.HTTP_400_BAD_REQUEST)

        # Send data to destinations
        for destination in account.destinations.all():
            headers = destination.headers
            url = destination.url
            http_method = destination.http_method

            try:
                if http_method == "GET":
                    response = requests.get(url, params=data, headers=headers)
                elif http_method == "POST":
                    response = requests.post(url, json=data, headers=headers)
                elif http_method == "PUT":
                    response = requests.put(url, json=data, headers=headers)

                response.raise_for_status()
            except requests.RequestException as e:
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response({"status": "Data successfully sent"}, status=status.HTTP_200_OK)
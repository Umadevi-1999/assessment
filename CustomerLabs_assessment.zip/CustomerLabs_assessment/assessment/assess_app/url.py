from django.urls import path
from .views import (
    AccountViewSet,
    AccountDetailViewSet,
    DestinationViewSet,
    DestinationDetailViewSet,
    AccountDestinationsView,
    IncomingDataView,
)

urlpatterns = [
    path("accounts/", AccountViewSet.as_view(), name="account-list"),
    path("accounts/<int:pk>/", AccountDetailViewSet.as_view(), name="account-detail"),
    path("destinations/", DestinationViewSet.as_view(), name="destination-list"),
    path("destinations/<int:pk>/", DestinationDetailViewSet.as_view(), name="destination-detail"),
    path("accounts/<uuid:account_id>/destinations/", AccountDestinationsView.as_view(), name="account-destinations"),
    path("server/incoming_data/", IncomingDataView.as_view(), name="incoming-data"),
]
from django.apps import AppConfig


class AssessAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'assess_app'
